import PaginationView from './PaginationView'

export default PaginationView
