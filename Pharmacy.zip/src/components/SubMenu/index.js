import SubMenuView from './SubMenuView';

export default SubMenuView;
