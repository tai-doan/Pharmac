import MenuView from './MenuView';

export default MenuView;
