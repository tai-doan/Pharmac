import InsImportContainer from './InsImportContainer';

export default InsImportContainer;
