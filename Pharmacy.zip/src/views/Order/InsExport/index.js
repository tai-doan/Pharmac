import InsExportContainer from './InsExportContainer';

export default InsExportContainer;
