import ForgotPassContainer from './ForgotPassContainer';

export default ForgotPassContainer;
