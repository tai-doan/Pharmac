import GetlistContainer from './GetlistContainer';

export default GetlistContainer;
