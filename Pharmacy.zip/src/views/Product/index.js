// import ProductContainer from './ProductContainer';
import GetlistContainer from './Getlist/GetlistContainer'

export default GetlistContainer
