import InsContainer from './InsContainer';

export default InsContainer;
