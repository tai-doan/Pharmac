import ProductTypeContainer from './ProductTypeContainer';

export default ProductTypeContainer;
