import CustomerContainer from './CustomerContainer';

export default CustomerContainer;
