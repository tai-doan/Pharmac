import InsCusContainer from './InsCusContainer';

export default InsCusContainer;
