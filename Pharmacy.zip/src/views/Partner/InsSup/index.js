import InsSupContainer from './InsSupContainer';

export default InsSupContainer;
