import PartnerContainer from './PartnerContainer';

export default PartnerContainer;
