import SuppliersContainer from './SuppliersContainer';

export default SuppliersContainer;
