import InventoryContainer from './InventoryContainer';

export default InventoryContainer;
