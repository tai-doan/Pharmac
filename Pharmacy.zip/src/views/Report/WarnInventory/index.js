import WarnInventoryContainer from './WarnInventoryContainer';

export default WarnInventoryContainer;
