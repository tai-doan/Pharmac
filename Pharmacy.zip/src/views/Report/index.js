import ReportContainer from './ReportContainer';

export default ReportContainer;
