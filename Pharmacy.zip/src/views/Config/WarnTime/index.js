import WarnTimeContainer from './WarnTimeContainer';

export default WarnTimeContainer;
