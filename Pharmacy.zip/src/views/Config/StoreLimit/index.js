import StoreLimitList from './StoreLimitList';

export default StoreLimitList;
