import PriceList from './PriceList';

export default PriceList;
