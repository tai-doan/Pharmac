import RegistContainer from './RegistContainer';

export default RegistContainer;
