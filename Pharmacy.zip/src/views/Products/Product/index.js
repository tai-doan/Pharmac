import Product from './ProductList';

export default Product
