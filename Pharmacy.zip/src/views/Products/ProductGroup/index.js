import ProductGroupList from './ProductGroupList';

export default ProductGroupList
